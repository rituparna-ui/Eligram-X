const service = {
  type: 'service_account',
  project_id: 'rituparna-a',
  private_key_id: '55c2b3cdd3ccbe931f2d9589540d46fe96aba8e7',
  private_key:
    '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDoV2l+KIT77qpr\nm/FW8ap9JVDQvGRueyhCdts3yNkJQU8BLmqkPGRoHK9plFqufwMfTlnxfiMO7RRs\nWglKPwclGCfonMjVNtIFWVxGhB+1fO2s9s7IMgnPcNeLfJtPQQfV1HU/yJW9/yNl\ns9Rc1i30RzPHMEu1VS9MuEj3x2if4f00UjcRGBzzLM+4/5Wc4zJZLbFqUJKy9U3p\n3s+ho8uPLwac3ayP8/lHenhc8cceXgAVYlbTGGgTBolUNxy+wmIZEEigJOn1ied6\nEUPTDLmFPL26550G7iI+PaJaY8MEaO7Hq6jZQ84Do4QSHNbidL4LhsGviEYiEN9q\neVC1/14XAgMBAAECggEAbuNtQ1t2YMEfUB2MuTi87F6XbBBGBJ69777HUKAIycyE\nNuWe2wTBzRjHtWWrQ/X1mQbtkX7on5KSOUZdgbSEJfWZ8oCFr5Eq+oeULUmY0qct\nzmu69DxBh2JtVTLi8xfv8+OjFA6ZPSVckQkbVTWZmCk1cp8/uutNmFmp5awj6I3r\n3OOGh/IplvkM/L7Quzk4+ygM/63LLjUo6dUO0PVvhYc2YbbPOBHkme6+tAEaHc4N\ncfACdUzkpGoQ75xoWidbUFYSy49M25+P/2biWuHLvKoPdBxAxwyed2pGjJLjsEBg\nBYc7+/4HCCK+wUjqWmcVB1K1xduoI7GVhXekGjR5HQKBgQD0rsnNuTlg1QVcMACj\n7Ppimi+zC1H/KvOJCtxMbR0t68+aJrQAR8KpujxUhe7gBQ7PMTw6gp7F4WuykbFK\nvsuhWg4SKJ2lav0HVaou7S4aUypxBKxWRjOGUAYrLvYI0n2PGcQQLBxXYLU1CyN7\nxv8XHNKVyLTAi+LOpD2ykbBaEwKBgQDzFn6CRPybrFWvosdeAD/LikqrUAGTu1Zo\njcEExkDndoYPPHj3Hkhk0hehcienhrgFQ3yfO02OZJKENpjbm6X+BazC05ZXGat5\n/tH7WhBxugr3IPwfDzk8a7qHY3bssk9Jz590JZ4+0heOOVDTtTgJDbNls0bK99o0\ne6mJFZNsbQKBgQDzjiS8TZpKw+AhAnswsQwPKDFAxIzrNQLTr+bXgGliM28jn1Df\nUo73SbUR4XuErCQwo26zQx/uEtOUHSfgIgkp5C1Lb/h0FwokyeWr7lVMyOnfM+qj\nuh9Bm9h4Fbe70mI/FkOuYWoYo9/cG+lHJS73/62ygOVDIDs0vBHZ9OEY1wKBgEul\nElUjdqBS7o8rTnMYDMIgFMBesz7vqyH6CriboRLmNS2Emff8ena1UhkxVtmw+I7a\nw2shny7SaS2vd73PH8Z+qZYvFbehC1V5UIqxKjDZvhPNNefMavk8ZN1AvH9HtZi4\nfVw9YJMX+bCOcXKQEBHxK4RYV41Nt59hZA5+olO5AoGBAJJXpMMlqixJCTUP0Sn7\nazyzO8gtMMovh6z9zsgGyissTtS6FK2rrDK/lZ89E6fuls3ZIWyiU+qlJvgMF3C+\n3G+vLUElODt3K/W8Vt9WTnfEzPHfAY0KOCPk0a+2NXNPGV3KGODrkKp6UDDhAXZo\nOkKr7FANBHhkmCevKn0H+jZk\n-----END PRIVATE KEY-----\n',
  client_email: 'firebase-adminsdk-b2d88@rituparna-a.iam.gserviceaccount.com',
  client_id: '111457765777931645830',
  auth_uri: 'https://accounts.google.com/o/oauth2/auth',
  token_uri: 'https://oauth2.googleapis.com/token',
  auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
  client_x509_cert_url:
    'https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-b2d88%40rituparna-a.iam.gserviceaccount.com',
};

module.exports = service;
